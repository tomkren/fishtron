
-----------------------------------------------------------------------------------------

If any troubles occur or if You prefer it for any other reason you can contact me on
tomkren@gmail.com
or +420 776 147 881
and I will gladly show You the program personally.

-----------------------------------------------------------------------------------------

First copy the contents of this CD to Your computer.

In order to run the program, the Haskell Platform must be installed -
the program must be compiled on Your machine, because the Haskell interpreter is used for evaluating individuals.

Installator for Haskell Platform for Windows is provided on this CD.
The program will probably also work OK on Linux, but we do not include installation
since this depends on specific distribution.

Haskell Platform for various systems can be downloaded here, including
many Linux distributions : http://www.haskell.org/platform/ 

After installing the Haskell Platform, run the install.bat file.
This step will need connection to the internet - it will download all needed libraries and compile them. 
Despite being .bat file, it can be also run on Linux system, since it is only a series of 
commands runing cabal program (installed with the Haskell Platform) with different arguments.

After successful installation run compile-and-run.bat file. This will compile and run 
the program. Again despite it is .bat it should work OK on Linux. 
Firewall pop-up will be probably prompted, the program must be granted access.


Recapitulated 4 steps are:

COPY whole CD to computer
INSTALL The Haskell Platform
RUN install.bat
RUN compile-and-run.bat


I am sorry for complicated installation - I was trying hard to overcome this difficulties but since interpreter needs
it I was unsuccessful and lost time to prepare the installation in an easier form.

-----------------------------------------------------------------------------------------------

To access the GUI of the program, open http://localhost:3000 in a web browser (Chrome and Firefox works OK, IE not).

The GUI consists of several Tabs, experiment can be started from the initial "Params" tab.
In the dropdown are prepared experiments mentioned in the thesis text 
(both experiments for SSR, both experiments for ANT, only two experiments for EvenPArity
because i was doing changes directly to the code and haven't enough time to make it controllable from outside, 
and final experiment of Fly and Apple) and two more other experiments unmentioned in text.
The number of runs, number of generations and population size may be changed in the GUI.



------------------------------------------------------------------------------------------------------

Folder reports contains more detailed info about experiments mentioned in the thesis.
Files CD/src/data/fly-BO1.html 
  and CD/src/data/fly-BO2.html are galleries of individuals from some interesting runs 
                               of Fly and Apples problem (BO1 is before increase of default energy).
   

