
$(document).ready(function() {

console.log( "Ant2.js ready!" );  

var antState2; 


Global.Problems.ant2 = {


  onLoadedProblemData : function( data ){ 
    this.antState2.loadResources();
  },


  onGo : function(){
    
    $('#special').html( 
      '<b>Each number</b> (=fitness) <b>link represents one best-of-generation individual. Click it and see!</b>'+
      '<div id="ant-links"></div><br>' +
      '<canvas id="antCanvas" width="517" height="517"></canvas>' );

    this.solutions     = [] ;
    this.i             = 0  ;

    this.antState2.init();

  },


  fenotyp : function( solution , ffVal ){

    this.solutions[this.i] = solution ;
    $('#ant-links').append( '<a href="#" title="'+ solution +'" '+
      'onclick="Global.Problems.ant2.link('+this.i+')">' +ffVal + '</a> ' );

    this.i ++ ;

  },




  link : function( i ){

    this.antState2.add( this.solutions[i]() );

  },

  antState2 : {
    pos : undefined,
    dir : undefined ,
    world : [],
    limit : 600,
    steps : undefined,
    eaten : undefined,
    ctx : undefined,
    antImg : {},
    seedImg : undefined,
    isRunning : false,
    progQueue : [],
    actAnt : 0,
    initWorldStrs :   
     [ ".FFF............................"
     , "...F............................"
     , "...F.....................FFF...." 
     , "...F....................F....F.." 
     , "...F....................F....F.." 
     , "...FFFF.FFFFF........FF........." 
     , "............F................F.." 
     , "............F.......F..........." 
     , "............F.......F..........." 
     , "............F.......F........F.." 
     , "....................F..........." 
     , "............F..................." 
     , "............F................F.." 
     , "............F.......F..........." 
     , "............F.......F.....FFF..." 
     , ".................F.....F........" 
     , "................................" 
     , "............F..................."             
     , "............F...F.......F......."
     , "............F...F..........F...." 
     , "............F...F..............."             
     , "............F...F..............."
     , "............F.............F....." 
     , "............F..........F........" 
     , "...FF..FFFFF....F..............." 
     , ".F..............F..............." 
     , ".F..............F..............." 
     , ".F......FFFFFFF................." 
     , ".F.....F........................" 
     , ".......F........................" 
     , "..FFFF.........................." 
     , "................................" ],

    loadResources : function(){

      var dirs = [ 'u' , 'd' , 'l' , 'r' ];

      for( var i in dirs ){
        antState2.antImg[ dirs[i] ] = new Image();  
        antState2.antImg[ dirs[i] ].src = 'img/ant-'+ dirs[i] +'.png';      
      }
      antState2.seedImg = new Image();
      antState2.seedImg.src = 'img/weed.png' ;

    },

    init : function(){

      antState2.steps = 0;
      antState2.eaten = 0;
      antState2.dir   = 'r'; 
      antState2.pos   = [0,0] ;  

      for( var i in antState2.initWorldStrs ){
        var lineStr = antState2.initWorldStrs[i] ;
        antState2.world[i] = [];
        for( var j in lineStr ){
          antState2.world[i][j] = (lineStr[j] == 'F') ;
        }
      }

      antState2.drawInit();

      antState2.draw();
    },

    drawInit : function(){

      if( ! $('#antCanvas').length ){
        $('#special').html(
           '<canvas id="antCanvas" width="517" height="517"></canvas>'+
           '<div id="antLogs" style="position:relative;top:-520px;left:520px;"></div>'
         );
        var canvas = document.getElementById('antCanvas');
        antState2.ctx = canvas.getContext('2d');
      } else {
        antState2.ctx = $('#antCanvas')[0].getContext('2d');
      }
    },

    draw : function(){

      antState2.ctx.clearRect(0, 0, 16*32 +5, 16*32 +5);

      antState2.drawAnt();

      for( var i in antState2.world ){
        for( var j in antState2.world[i] ){
          if( antState2.world[i][j] ){
            antState2.drawSeed(i,j);
          }
        }
      }

    },

    drawAnt : function(){
      antState2.ctx.drawImage( antState2.antImg[ antState2.dir ] , antState2.pos[1]*16 , antState2.pos[0]*16 );
    },

    drawSeed : function(i,j){
      antState2.ctx.drawImage( antState2.seedImg , j*16 - 4 , i*16 );
    },

    show : function(){
      var ret = '\n' ;
      for( var i in antState2.world ){
        for( var j in antState2.world[i] ){
          if( i == antState2.pos[0] && j == antState2.pos[1] ){
            ret = ret + antState2.dir ;
          }else{
            ret = ret + (antState2.world[i][j] ? 'F' : '.') ; 
          }
        }
        ret = ret + '\n' ;
      }

      ret = ret + 'eaten : ' + antState2.eaten + '\n' ;
      ret = ret + 'steps : ' + antState2.steps ;

      return ret ;
    },

    ahead : function(){
      var p0 = antState2.pos[0];
      var p1 = antState2.pos[1];
      switch( antState2.dir ){
        case 'r' : p1 = (p1+1+32) % 32 ; break;
        case 'l' : p1 = (p1-1+32) % 32 ; break;
        case 'u' : p0 = (p0-1+32) % 32 ; break;
        case 'd' : p0 = (p0+1+32) % 32 ; break;
      }
      return [p0,p1] ;
    },  

    reachedLimit : function(){
      return antState2.steps >= antState2.limit ;
    },

    doMove : function(){
      if( antState2.reachedLimit() ){ return; }

      var ah = antState2.ahead();
      antState2.pos[0] = ah[0];
      antState2.pos[1] = ah[1];

      if( antState2.world[ah[0]][ah[1]] ){
        antState2.eaten ++ ;
        antState2.world[ah[0]][ah[1]] = false ;
      }

      antState2.steps ++ ;
      antState2.draw();
    },

    doLeft : function(){

      if( antState2.reachedLimit() ){ return; }

      switch( antState2.dir ){
        case 'r' : antState2.dir = 'u' ; break;
        case 'l' : antState2.dir = 'd' ; break;
        case 'u' : antState2.dir = 'l' ; break;
        case 'd' : antState2.dir = 'r' ; break;
      }

      antState2.steps ++ ; 
      antState2.draw();   
    },

    doRight : function(){
      if( antState2.reachedLimit() ){ return; }

      switch( antState2.dir ){
        case 'r' : antState2.dir = 'd' ; break;
        case 'l' : antState2.dir = 'u' ; break;
        case 'u' : antState2.dir = 'r' ; break;
        case 'd' : antState2.dir = 'l' ; break;
      } 

      antState2.steps ++ ;  
      antState2.draw(); 
    },

    isFoodAhead : function(){
      var ah = antState2.ahead( );
      return antState2.world[ah[0]][ah[1]];
    },

    run : function( prog ){

      //console.log(prog);
      //haxx = prog;

      var stepoid = function(){
        if( ! antState2.reachedLimit() ){
          prog();
          setTimeout( stepoid , 50 );
        }else{
          antState2.isRunning = false ;
          if( antState2.progQueue.length ){
            antState2.start( antState2.progQueue.shift() );
          }
        }
      };

      stepoid();

    },

    start : function( prog ){
        antState2.isRunning = true;
        antState2.init();
        var antI = ++ antState2.actAnt ;
        antState2.run( prog );
    },

    add : function( prog ){



      if( antState2.isRunning ){

        antState2.progQueue.push( prog );
      } else {
        antState2.start( prog );
      }

    },


  },



};

antState2 = Global.Problems.ant2.antState2; // kvuli tomu, že v antState2 se furt odkazuje na promenou 
                                         // antState2... (v puvodnim umisteni kodu to nebyla takova prasarna)

// HAX (!) schvalne tu nejsou var před nima

l   = antState2.doLeft  ;
r   = antState2.doRight ;
m   = antState2.doMove  ;
p2  = function( a1 , a2 ){ return function(){ a1() ; a2() ; } }
p3  = function(a1,a2,a3 ){ return function(){ a1() ; a2() ; a3() ;} }
ifa = function( a1 , a2 ){ return function(){if( antState2.isFoodAhead() ){ a1(); }else{ a2(); } } }




});

//var l   ;
//var r   ;
//var m   ;
//var p2  ;
//var p3  ;
//var ifa ;
